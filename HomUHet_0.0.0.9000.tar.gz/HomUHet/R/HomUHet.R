#' identify homogeneous and heterogeneous effects of predictors in multiple datasets
#'
#' classify the predictors into homogeneous, heterogeneous and unassociated categories. outputs the solution path plots.
#'
#'
#' The only function you're likely to need from \pkg{HomUHet} is
#' \code{\link{HomUHet}}. Otherwise refer to the vignettes to see
#' how to format the documentation.
"_PACKAGE"
#> [1] "_PACKAGE"
#'
#' fit a two-step penalized regression model
#'
#' This function outputs the names of predictors with homogeneous or heterogeneous predictors across multiple data sets, the estimates of predictors, and solution plots
#'
#' @param x the predictor matrix. a matrix of n x J containing observations from all studies for all predictors
#' @param y the response variable. a vector of n observations for the response variable
#' @param sid a vector of integers indexing the study id for each observation in data
#' @return the names of identified predictors and their estimated effects
#'  \item{Homo}{a character string of names of homogeneous predictors}
#'  \item{Heter}{a character string of N=names of heterogeneous predictors}
#'  \item{coefficients}{estimated coefficients of the homogeneous and heterogeneous predictors in K studies}
#'
#' @importFrom dplyr arrange group_by summarise_all
#' @importFrom graphics abline plot
#' @importFrom stats coef lm logLik var
#' @import glmnet
#' @import gglasso
#'
#'
#' @export
HomUHet<-function(x,y,sid){
  ##### sorting data by study
  data=cbind(y,x)
  data=as.data.frame(cbind(sid,data))
  data=dplyr::arrange(data,sid)
  n=as.data.frame(table(sid))[,2]
  x=as.matrix(data[,-c(1:2)])
  y=data[,2]
  sid=data[,1]
  J=ncol(x)
  K=length(unique(sid))
  lambda=c(0,0)
  lambda[1]=ifelse(sum(n)>J,0.0001,0.01)
  lambda[2]=ifelse(sum(n)>(J*K),0.001,0.05)






  #### fitting adaptive LASSO with BIC

  ini.beta<-glmnet::cv.glmnet(as.matrix(x),y,alpha=0,standardize=FALSE)

  beta.bic.fit<-glmnet::glmnet(as.matrix(x),y,alpha=1,penalty.factor=1/abs(coef(ini.beta,s="lambda.min")[-1]),standardize=FALSE,lambda.min.ratio = lambda[1])
  Bic<-function(y,x,beta,df){
    bic=length(y)*log(sum((y-x%*%beta)^2)/length(y))+log(length(y))*df
  }
  bic_score=rep(0,length(beta.bic.fit$df))
  for (q in 1:length(beta.bic.fit$df)){
    bic_score[q]=Bic(y,x,beta.bic.fit$beta[,q],beta.bic.fit$df[q])
  }
  Bic_optimal=which.min(bic_score)
  non.zero.beta=which(beta.bic.fit$beta[,Bic_optimal]!=0)
  zero.beta=which(beta.bic.fit$beta[,Bic_optimal]==0)


  #### finding OLS estimates for beta j
  data=as.data.frame(cbind(y,x[,non.zero.beta]))
  beta.ls.fit<-lm(y~.,data=data)

  y.res=y-cbind(rep(1,length(y)),x[,non.zero.beta])%*%beta.ls.fit$coefficients

  ### step 1 estimates
  step1_estimates=beta.bic.fit$beta[,Bic_optimal]

  step1_estimates[non.zero.beta]=beta.ls.fit$coefficients[-1]

  ##### creating joint data set


  x.by.var<-matrix(0,nrow=sum(n),ncol=J*K)

  for (j in 1:J){

    for (i in 1:K){
      temp=x.by.var[,((j-1)*K+1):(j*K)]

      if(i<2){
        temp[1:n[i],i]=x[1:n[i],j]
      }

      else
        temp[(sum(n[seq(1:(i-1))])+1):(sum(n[seq(1:(i))])),i]=x[(sum(n[seq(1:(i-1))])+1):(sum(n[seq(1:(i))])),j]

      x.by.var[,((j-1)*K+1):(j*K)]=temp
    }
  }

  ##### fitting group lasso



  group=rep(0,J*K)
  for (j in 1:J){

    group[((j-1)*K+1):(j*K)]=rep(j,K)

  }



  #### obtaining preliminary fit for delta j

  ini.delta.cv.fit<-glmnet::cv.glmnet(as.matrix(x.by.var),y.res,alpha=0,standardize=FALSE,intercept=TRUE)
  ini.delta.fit<-glmnet::glmnet(as.matrix(x.by.var),y.res,alpha=0,standardize=FALSE,intercept=TRUE,
                        lambda=ini.delta.cv.fit$lambda.min)

  ini.delta.norm=rep(0,J)
  ini.delta=ini.delta.fit$beta
  for (j in 1:J){
    ini.delta.norm[j]=norm(ini.delta[((j-1)*K+1):(j*K)],type="2")

  }




  #### fitting with all delta-j






  ebic.grp.fit<-gglasso::gglasso (as.matrix(x.by.var), y.res, group = group,
                         loss = "ls",
                         nlambda = 100,
                         lambda.factor = lambda[2],
                         pf = rep(sqrt(K),J)/(ini.delta.norm+0.000000000001),
                         dfmax = 1400,
                         pmax = 1400,
                         eps = 1e-08, maxit = 3e+08, intercept=TRUE)



  ####creating separate dataset

  data.by.study<-list()

  data.by.study[[1]]=cbind(y.res[1:(n[1])],x[1:(n[1]),])


  for (k in 2:K){

    data.by.study[[k]]=cbind(y.res[(sum(n[1:(k-1)])+1):sum(n[1:k])],x[(sum(n[1:(k-1)])+1):sum(n[1:k]),])
  }




  third.term.grp<-function(x,J,K,gamma){

    num.p=length(x)/K

    if (num.p==0){
      factorial.part=0
    }
    else
      factorial.part=sum(log(seq(1:J)))-(sum(log(seq(1:num.p)))+sum(log(seq(1:(J-num.p)))))
    third.term=2*gamma*factorial.part
    return(third.term)
  }


  index=abs(ebic.grp.fit$beta)>0
  L=which.max(which(ebic.grp.fit$df<((n[which.min(n)]*2/3)*K)))
  ebic=rep(0,L)

  for (l in 1:length(ebic)){

    temp.select_index=unique(group[index[,l]])

    temp.fit=as.data.frame(cbind(as.factor(group),(ebic.grp.fit$beta)[,l]))

    temp.selection=temp.fit[temp.fit$V1%in%temp.select_index,2]

    temp.third=third.term.grp(temp.selection,J,K,1)

    temp.ls.fit.lik=rep(0,K)

    if (l<2){

      for (k in 1:K){
        temp.data=as.data.frame((data.by.study[[k]])[,1])
        names(temp.data)=c("V1")
        temp.ls.fit=lm(V1~.,data=temp.data)
        temp.ls.fit.lik[k]=logLik(temp.ls.fit)
      }


    }else
    {
      temp.ls.coef=matrix(0,nrow=K,ncol=length(temp.select_index))
      for (k in 1:K){
        temp.data=as.data.frame(cbind((data.by.study[[k]])[,1],((data.by.study[[k]])[,-1])[,temp.select_index]))
        temp.ls.fit=lm(V1~.,data=temp.data)
        temp.ls.fit.lik[k]=logLik(temp.ls.fit)
        temp.ls.coef[k,]=temp.ls.fit$coefficients[-1]
      }

    }


    temp.dev=-2*(sum(temp.ls.fit.lik))
    norm.lasso=rep(0,length(temp.selection)/K)
    norm.ls=rep(0,length(temp.selection)/K)
    if (length(temp.selection)/K>0){
      for (i in 1:(length(temp.selection)/K)){

        norm.lasso[i]=norm(temp.selection[((i-1)*K+1):(i*K)],type="2")

        temp.ls.coef[is.na(temp.ls.coef[,i]),i]=0### replace NA by 0, ls fit model saturation
        norm.ls[i]=norm(temp.ls.coef[,i],type="2")
      }
      temp.df=length(temp.selection)/K+(K-1)*sum(norm.lasso/norm.ls)
    }else

    {temp.df=0}

    ebic[l]=temp.dev+temp.df*log(length(y.res))+temp.third

  }






  ebic.lambda=ebic.grp.fit$lambda[which.min(ebic)]

  ebic.coef=ebic.grp.fit$beta[,which.min(ebic)]

  ebic.fitted.delta=as.data.frame(cbind(as.factor(group),ebic.coef))


  ebic.selection=ebic.fitted.delta%>%dplyr::group_by(V1)%>%dplyr::summarise_all(var)### sd not working




  #### assessing performance

  Homo=intersect(non.zero.beta,which(ebic.selection[,2]==0))
  Heter=which(ebic.selection[,2]!=0)
  noise=intersect(zero.beta,which(ebic.selection[,2]==0))

  #### estimates
  if (length(Homo)>0){
    Homo_estimates=matrix(0,ncol=(K+1),nrow=length(Homo))
    for (r in 1:length(Homo)){
      Homo_estimates[r,]=c(Homo[r],rep(step1_estimates[Homo[r]],K))
    }
    Homo_estimates=as.matrix(Homo_estimates)
  } else {
    Homo_estimates=NULL
  }

  if (length(Heter)>0){
    Heter_estimates=matrix(0,ncol=(K+1),nrow=length(Heter))

    for (p in 1:length(Heter)){
      Heter_estimates[p,]=c(Heter[p],ebic.fitted.delta[ebic.fitted.delta$V1==Heter[p],2]+step1_estimates[Heter[p]])
    }

    Heter_estimates=as.matrix(Heter_estimates)
  } else {
    Heter_estimates=NULL
  }

  Homo_estimates=cbind(Homo_estimates,rep("Homogeneous", nrow(Homo_estimates)))

  Heter_estimates=cbind(Heter_estimates,rep("Heterogeneous", nrow(Heter_estimates)))


  coefficients=rbind(c("predictor",paste("study",seq(1:K),sep=""),"type"),
                  Homo_estimates,
                  Heter_estimates)

  list(Homo=Homo,
       Heter=Heter,
       coefficients)
}

#' Plot the solution path from HomUHet
#'
#' This function outputs the solution path plots
#'
#' @param fit the output object from HomUHet
#' @param y_name if needed, a response variable name for the solution path plots. Default is NULL.
#' @importFrom graphics abline plot
#' @return solution path plots from Step 1 and Step 2
#' @export
HomUHet.plot<-function(fit,y_name=NULL){
  step1_plot=plot(beta.bic.fit,xvar = "lambda",main=paste(y_name,"step1",sep = " "))
  abline(v=log(beta.bic.fit$lambda[Bic_optimal]))
  step2_plot=plot(ebic.grp.fit,main=paste(y_name,"step2",sep = " "))
  abline(v =log(ebic.lambda))
}

#' simulate multiple data sets with both homogeneous and heterogeneous effects from the predictors
#'
#' this function simulate data
#'
#' @param Pred_type the predictor type; choose between continuous or SNP
#' @param J the number of predictors. J should be at least 300.
#' @param K the number of studies.
#' @param level the level of heterogeneity. "l" stands for low, "m" stands for medium, and "h" stands for high.
#' @param rho a number between 0 and 1. controlling the degree of correlation between predictors
#' @param sigma a positive number. controlling the added noise to the simulated response variable
#' @param nlower the lower bound of the K sample sizes
#' @param nupper the upper bound of the K sample sizes
#' @importFrom MASS mvrnorm
#' @return the simulated data
#' \item{x}{an n x J matrix containing simulated predictors}
#' \item{y}{an n-length vector of simulated response variable}
#' \item{sid}{an n-length vector of integers containing the study id for each observation in data}
#' @export
HomUHet.sim<-function(Pred_type=c("Con","SNP"),J=1400,K=c(4,10),level=c("l","m","h"),rho=0.5,sigma=2,nlower=50,nupper=300){
  v=c(1,rep(NA,(J-1)))

  for (i in 2:J){
    v[i]=rho^(i-1)
  }

  Sigma=toeplitz(v)
  t=0
  x=rep(0,J)
  y=0
  sid=0
  b=rep(0,40)
  n=0

  if (K==4){
    if (level=="l"){
      fixed.b=c(runif(5,1,3),runif(5,-3,-1))
      b.matrix=matrix(0,ncol=30,nrow=K)

      for (j in 1:30){
        if (j<11){
          b.matrix[,j]=sample(c(runif(2,1,1.5),runif(2,-1.5,-1)),K)
        }

        else {if (j<21){
          b.matrix[,j]=sample(c(runif(1,1,1.5),runif(1,2,2.5),runif(2,3,3.5)),K)
        }
          else {
            b.matrix[,j]=sample(c(runif(1,-1.5,-1),runif(1,-2.5,-2),runif(2,-3.5,-3)),K)
          }
        }
      }
      modified.b.matrix<-matrix(0,ncol=60,nrow=K)

      for (j in 1:30){

        modified.b.matrix[,(j*2-1)]=b.matrix[,j]
      }

    } else if (level=="m"){
      fixed.b=c(runif(5,1,3),runif(5,-3,-1))
      b.matrix=matrix(0,ncol=30,nrow=K)

      for (j in 1:30){
        if (j<11){
          b.matrix[,j]=sample(c(runif(2,2,2.5),runif(2,-2.5,-2)),K)
        }

        else {if (j<21){
          b.matrix[,j]=sample(c(runif(1,1,1.5),runif(1,3,3.5),runif(2,5,5.5)),K)
        }
          else {
            b.matrix[,j]=sample(c(runif(1,-1.5,-1),runif(1,-3.5,-3),runif(2,-5.5,-5)),K)
          }
        }
      }

      modified.b.matrix<-matrix(0,ncol=60,nrow=K)

      for (j in 1:30){

        modified.b.matrix[,(j*2-1)]=b.matrix[,j]
      }

    } else {
      fixed.b=c(runif(5,3,6),runif(5,-6,-3))
      b.matrix=matrix(0,ncol=30,nrow=K)

      for (j in 1:30){
        if (j<11){
          b.matrix[,j]=sample(c(runif(2,5,6.5),runif(2,-6.5,-5)),K)
        }

        else {if (j<21){
          b.matrix[,j]=sample(c(runif(1,1,2),runif(1,5,6),runif(2,9,10)),K)
        }
          else {
            b.matrix[,j]=sample(c(runif(1,-2,-1),runif(1,-6,-5),runif(2,-10,-9)),K)
          }
        }
      }
      modified.b.matrix<-matrix(0,ncol=60,nrow=K)

      for (j in 1:30){

        modified.b.matrix[,(j*2-1)]=b.matrix[,j]
      }

    }} else {

      if (level=="l"){
        fixed.b=c(runif(5,1,3),runif(5,-3,-1))
        b.matrix=matrix(0,ncol=30,nrow=K)

        for (j in 1:30){
          if (j<11){
            b.matrix[,j]=sample(c(runif(5,1,1.5),runif(5,-1.5,-1)),K)
          }

          else {if (j<21){
            b.matrix[,j]=sample(c(runif(3,1,1.5),runif(3,2,2.5),runif(4,3,3.5)),K)
          }
            else {
              b.matrix[,j]=sample(c(runif(3,-1.5,-1),runif(3,-2.5,-2),runif(4,-3.5,-3)),K)
            }
          }
        }
        modified.b.matrix<-matrix(0,ncol=60,nrow=K)

        for (j in 1:30){

          modified.b.matrix[,(j*2-1)]=b.matrix[,j]
        }
      } else if (level=="m"){
        fixed.b=c(runif(5,1,3),runif(5,-3,-1))
        b.matrix=matrix(0,ncol=30,nrow=K)

        for (j in 1:30){
          if (j<11){
            b.matrix[,j]=sample(c(runif(5,2,2.5),runif(5,-2.5,-2)),K)
          }

          else {if (j<21){
            b.matrix[,j]=sample(c(runif(3,1,1.5),runif(3,3,3.5),runif(4,5,5.5)),K)
          }
            else {
              b.matrix[,j]=sample(c(runif(3,-1.5,-1),runif(3,-3.5,-3),runif(4,-5.5,-5)),K)
            }
          }
        }

        modified.b.matrix<-matrix(0,ncol=60,nrow=K)

        for (j in 1:30){

          modified.b.matrix[,(j*2-1)]=b.matrix[,j]
        }
      } else {
        fixed.b=c(runif(5,1,6),runif(5,-6,-1))
        b.matrix=matrix(0,ncol=30,nrow=K)

        for (j in 1:30){
          if (j<11){
            b.matrix[,j]=sample(c(runif(5,5,6.5),runif(5,-6.5,-5)),K)
          }

          else {if (j<21){
            b.matrix[,j]=sample(c(runif(3,1,2),runif(3,5,6),runif(4,9,10)),K)
          }
            else {
              b.matrix[,j]=sample(c(runif(3,-2,-1),runif(3,-6,-5),runif(4,-10,-9)),K)
            }
          }
        }
        modified.b.matrix<-matrix(0,ncol=60,nrow=K)

        for (j in 1:30){

          modified.b.matrix[,(j*2-1)]=b.matrix[,j]
        }
      }

    }

  if (Pred_type=="Con"){
    while (t<K){
      n.temp=sample(seq(nlower,nupper),1)
      n=c(n,n.temp)
      sid.temp=rep(t+1,n.temp)
      sid=c(sid,sid.temp)
      temp.x=MASS::mvrnorm(n.temp,mu=rep(0,J),Sigma=Sigma)
      temp.rb=c(fixed.b[1:5],rep(0,100),fixed.b[6:10],rep(0,100),modified.b.matrix[(t+1),])
      temp.y=rnorm(1,0,5)+temp.x[,1:270]%*%temp.rb+rnorm(n.temp,0,sigma)
      temp.y=temp.y
      x=rbind(x,scale(temp.x))
      y=c(y,temp.y)

      t=t+1
    }} else {
      allele.freq=runif(J,0.05,0.5)
      while (t<K){
        n.temp=sample(seq(nlower,nupper),1)
        n=c(n,n.temp)
        sid.temp=rep(t+1,n.temp)
        sid=c(sid,sid.temp)
        divider=rep(0,J)
        temp.x1=matrix(0,ncol=J,nrow=n.temp)
        temp.x2=matrix(0,ncol=J,nrow=n.temp)


        temp.z1=MASS:mvrnorm(n.temp,mu=rep(0,J),Sigma=Sigma)
        temp.z2=MASS:mvrnorm(n.temp,mu=rep(0,J),Sigma=Sigma)

        for (j in 1:J){

          temp.x1[,j]=ifelse(temp.z1[,j]<=qnorm(allele.freq[j]),1,0)
          temp.x2[,j]=ifelse(temp.z2[,j]<=qnorm(allele.freq[j]),1,0)
          divider[j]=sqrt(allele.freq[j]*(1-allele.freq[j]))



        }

        temp.x=temp.x1+temp.x2
        temp.rb=c(fixed.b[1:5],rep(0,100),fixed.b[6:10],rep(0,100),modified.b.matrix[(t+1),])/divider[1:270]
        temp.y=rnorm(1,0,5)+temp.x[,1:270]%*%temp.rb+rnorm(n.temp,0,sigma)
        temp.x=scale(temp.x)
        temp.x[is.na(temp.x)]<-0
        x=rbind(x,temp.x)

        y=c(y,temp.y)

        t=t+1
      }
    }
  x=x[-1,]
  y=y[-1]
  n=n[-1]
  sid=sid[-1]

  return(list(x,y,sid))
}




